# Flutter Login and SignUp Page

> Simple Flutter Login and SignUp Page.

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

---
## Screenshots]

<img src="assets/screenshot/Screenshot_20200530-170847.jpg" height="500em" />       <img src="assets/screenshot/Screenshot_20200530-170905.jpg" height="500em" />      <img src="assets/screenshot/Screenshot_20200530-170909.jpg" height="500em" />

## Contributing

> To get started...

### Step 1

- **Option 1**
    - 🍴 Fork this repo!

- **Option 2**
    - 👯 Clone this repo to your local machine using `https://github.com/alisolanki/LoginPage.git`

### Step 2

- **HACK AWAY!** 🔨🔨🔨

### Step 3

- 🔃 Create a new pull request using <a href="https://github.com/alisolanki/LoginPage/compare/" target="_blank">`https://github.com/alisolanki/LoginPage/compare/`</a>.

---

## Author
<table>
  <tr>
    <td align="center"><a href="http://www.alisolanki.gq"><img src="https://avatars3.githubusercontent.com/u/55312000?v=4" width="100px;" alt="Ali Solanki"/><br /><sub><b>Ali Solanki</b></sub></a><br/>💻</a>
    </td>
  </tr></table>

---

## License

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

- **[MIT license](http://opensource.org/licenses/mit-license.php)**
- Copyright 2020 © <a href="https://www.alisolanki.gq" target="_blank">Ali Solanki</a>.
